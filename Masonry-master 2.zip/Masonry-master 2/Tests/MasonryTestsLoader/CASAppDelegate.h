//
//  CASAppDelegate.h
//  MasonryTestsLoader
//
//  Created by Jonas Budelmann on 26/11/13.
//
//

#import <UIKit/UIKit.h>

@interface CASAppDelegate : UIResponder <UIApplicationDelegate>

@end
